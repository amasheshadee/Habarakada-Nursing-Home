const express = require('express');
const mysql = require('mysql');
const bodyparser = require('body-parser');
const cors = require('cors');

//create connection
const conn = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'habarakada_doctor_registration_db'
});

//connect to the db
conn.connect((err)=>{
    if(err){
        console.log(err);
    }
    else{
        console.log('MySql connected....');
    }
});

//setup express server
const app = express();
app.use(cors());
app.use(bodyparser.urlencoded({extended : true}));

//use body-parser middleware
app.use(bodyparser.json());

//insert doctor registration details
app.get('/doctorRegistrationDetails/:name/:contactNumber/:email/:address/:speciality/:currentWorkingHospital',(req,res) =>{
    let post = {Name:req.params.name,contact_number:req.params.contactNumber,email:req.params.email,address:req.params.address,speciality:req.params.speciality,Current_working_hospital:req.params.currentWorkingHospital}
    let sql = "INSERT INTO doctor_registration SET ?";
    let query = conn.query(sql,post,(err,result) => {
        if(err)throw err;
        console.log(result);
        console.log("details are inserted to habarakada_doctor_registration_details ");
    });
});

//Retriewing doctor registration details
app.get('/doctorfetching',(req,res)=>{
    res.set('Access-Control-Allow-Origin', '*');
    let sql = 'SELECT * FROM doctor_registration';
    let query = conn.query(sql, (err,result)=>{
        if(err) throw err;
        console.log(result);
        return res.json({
            //send data to html file as a json file
            data:result
        })
    });
    
    });

    //Retriewing drug reports
app.get('/drugreportfetching',(req,res)=>{
    res.set('Access-Control-Allow-Origin', '*');
    let sql = 'SELECT * FROM view_drug_reports';
    let query = conn.query(sql, (err,result)=>{
        if(err) throw err;
        console.log(result);
        return res.json({
            //send data to html file as a json file
            data:result
        })
    });
    
    });

    //doctor data retrieval

    app.get('/Updatefetching/:id',(req,res)=>{
        res.set('Access-Control-Allow-Origin', '*');
        let sql = `SELECT * FROM doctor_registration WHERE doctor_id= ${req.params.id}`;
            let query = conn.query(sql, (err,result)=>{
            if(err) throw err;
            console.log(result);
            return res.json({
                //send data to html file as a json file
                data:result
            })
        });
        
        });
    

//update doctor details
app.get('/UpdateDoctor/:id/:name/:contactNumber/:email/:address/:speciality/:currentWorkingHospital',(req,res)=>{
    console.log(req.params.id);
let sup = {Name:req.params.name,contact_number:req.params.contactNumber,email:req.params.email,address:req.params.address,speciality:req.params.speciality,Current_working_hospital:req.params.currentWorkingHospital};
let sql = `UPDATE doctor_registration SET Name ='${sup.Name}',contact_number ='${sup.contact_number}',email ='${sup.email}',address ='${sup.address}',speciality ='${sup.speciality}', Current_working_hospital ='${sup.Current_working_hospital}'WHERE doctor_id= ${req.params.id}`;
let query = conn.query(sql,(err,result) =>{
    if(err) throw err;
    console.log(result);
    console.log('Doctor updated');
});
});




//deleting doctor details
app.get('/Doctordelete/:id',(req,res)=>{
    res.set('Access-Control-Allow-Origin', '*');
    let sql = `DELETE FROM doctor_registration WHERE doctor_id= ${req.params.id}`;
        let query = conn.query(sql, (err,result)=>{
        if(err) throw err;
        console.log(result);
        return res.json({
            //send data to html file as a json file
            data:result
        })
    });
    
    });



    
//start the server
app.listen('3000', () => {
    console.log('server started on port 3000');
});
