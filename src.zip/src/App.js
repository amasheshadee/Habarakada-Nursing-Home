import React, { Component } from 'react';

import {
  BrowserRouter as Router,
  Route,
  Link,
  HashRouter 

}from 'react-router-dom';

import Header from './component/headercomponent/header';
import Footer from './component/footercomponent/footer';
import doctorRegistration from './component/doctorReg/doctorRegistration';
import ViewDoctors from './component/ViewDoctors/ViewDoctors';
import ViewDrugReports from './component/ViewDrugReports/ViewDrugReports';
import updateDoctorDetails from './component/updatedoctordetails/updateDoctorDetails';


function App() {
  return (
    <HashRouter>
    <div className="App">
      <Header />
        <Route exact path='/doctorRegistration' component={doctorRegistration}/>
        <Route exact path='/' component={ViewDoctors}/>
        <Route exact path='/ViewDrugReports' component={ViewDrugReports}/>
        <Route exact path ='/updateDoctorDetails/:id' component = {updateDoctorDetails}/>
      <Footer />
    </div>
    </HashRouter>
  );
}

export default App;
