import {render} from '@testing-library/react';
import React,{Component} from 'react';
import {Form, Button} from 'react-bootstrap';

export class updateDoctorDetails extends React.Component{


    state={
        name :'',
        contactNumber :'',
        email:'',
        address:'',
        speciality:'',
        currWorkingHospital:''
      }
    


    handlerChange = (e) =>{
        this.setState({[e.target.name]:e.target.value})
    }
    constructor(props){
        super(props);
        this.state={
            error :null,
            isLoaded:false,
            details:[]
        };
    }

    handlerSubmit = (e) =>{
        //event.preventDefault();
        const doctorDetails = {
          name : this.state.name,
          contactNumber:this.state.contactNumber,
          email:this.state.email,
          address:this.state.address,
          speciality:this.state.speciality,
          currWorkingHospital:this.state.currWorkingHospital
        

        }

        alert(this.props.match.params.id);
        alert(doctorDetails.speciality);

        fetch(`http://localhost:3000/UpdateDoctor/${this.props.match.params.id}/${doctorDetails.name}/${doctorDetails.contactNumber}/${doctorDetails.email}/${doctorDetails.address}/${doctorDetails.speciality}/${doctorDetails.currWorkingHospital}`,{
            method: 'GET'
    }).then(function(response){
        return response.json();
    }).then(function(json){
        //json -> your response from the server
    }).catch(function(error){
        //Hadle errors here
    });
    }
    componentDidMount(){
        alert(this.props.match.params.id);

            fetch(`http://localhost:3000/Updatefetching/${this.props.match.params.id}`)
            
              .then(res => res.json())
              .then(
                  (result) =>{
                      this.setState({

                        isLoaded:true,
                        details:result.data
                      });
                      console.log(result.data);
                    },
                    (error) => {

                        this.setState({

                            isLoaded:true,
                            details:[],
                            error :error
                        });
                    }

              )

            }

deleteItems = () =>{

alert(this.props.match.params.id)
fetch(`http://localhost:3000/Doctordelete/${this.props.match.params.id}`)
.then(res=>res.json())
.then(
    (result) =>{

        this.setState({

            isLoaded:true,
            items:result.data


        });

        console.log(result.data);
    },
    
        (error) =>{

            this.setState({

                    isLoaded:true,
                    items:[],
                    error:error

            });
        }


)

}


            render(){
                const{error,isLoaded,details} = this.state;
                if(error){
                    return <div> Error:{error.massage}</div>;

                }else if(!isLoaded){
                    return<div>Loading....</div>
                }else{
                    return(

                        <ul>
                                {details.map(detail=>(
                                       <div className = "wrap">
                                     <Form>
        <Form.Group controlId="formName">
          <Form.Label>Name</Form.Label>
          <Form.Control type="text" name = "name" onChange = {this.handlerChange} defaultValue = {detail.Name}  />
        </Form.Group>
      
        <Form.Group controlId="formContactDetails">
          <Form.Label>Contact Number</Form.Label>
          <Form.Control type="text" name = "contactNumber" onChange = {this.handlerChange} defaultValue = {detail.contact_number}  />
          
        </Form.Group>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control type="email" name = "email" onChange = {this.handlerChange} defaultValue = {detail.email} />
          <Form.Text className="text-muted">
            We'll never share your email with anyone else.
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formAddress">
          <Form.Label>Address</Form.Label>
          <Form.Control type="address" name = "address" onChange = {this.handlerChange} defaultValue = {detail.address} />
          
        </Form.Group>
        <Form.Group controlId="formSpeciality">
          <Form.Label>Speciality</Form.Label>
          <Form.Control type="text" name = "speciality" onChange = {this.handlerChange} defaultValue = {detail.speciality}  />
         
        </Form.Group>
        <Form.Group controlId="formHospital">
          <Form.Label>Current Working Hospital</Form.Label>
          <Form.Control type="text" name = "currWorkingHospital" onChange = {this.handlerChange} defaultValue = {detail.Current_working_hospital}  />
          
        </Form.Group>
        <Button variant="primary" type="submit" onClick = {this.handlerSubmit}>
          Update 
        </Button>

        <Button variant="primary" type="submit" onClick = {this.deleteItems}>
          Delete 
        </Button>
      </Form>
                                    </div>
                                                            

                                 ))};
                                  </ul>
                                  
                                  )
                                }
                            }
                        }export default updateDoctorDetails;

  
                                
                        