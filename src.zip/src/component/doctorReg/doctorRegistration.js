
import React,{Component}from 'react';
import {Link} from 'react-router-dom';
import {Form, Button} from 'react-bootstrap';

export class doctorRegistration extends Component{


  state={
    name :'',
    contactNumber :'',
    email:'',
    address:'',
    speciality:'',
    currWorkingHospital:''
  }

  handlerChange =(e) =>{
    this.setState({[e.target.name] : e.target.value})
  
  }


  handlerSubmit = (e) =>{
      //event.preventDefault();
      const doctorDetails = {
        name : this.state.name,
        contactNumber:this.state.contactNumber,
        email:this.state.email,
        address:this.state.address,
        speciality:this.state.speciality,
        currWorkingHospital:this.state.currWorkingHospital

      }
        alert(doctorDetails.name);
        fetch(`http://localhost:3000/doctorRegistrationDetails/${doctorDetails.name}/${doctorDetails.contactNumber}/${doctorDetails.email}/${doctorDetails.address}/${doctorDetails.speciality}/${doctorDetails.currWorkingHospital},`,{
        method:'GET'

        }).then(function(response){
          return response.json();


        }).then(function(json){
            //json-> is your response from server
        }).catch(function(error){
          //handle errors here
        });
  }

  render(){
    return(
    <div className = "doctorDetails">
    <Form>
        <Form.Group controlId="formName">
          <Form.Label>Name</Form.Label>
          <Form.Control type="text" name = "name" onChange = {this.handlerChange} placeholder="Enter Name" />
        </Form.Group>
      
        <Form.Group controlId="formContactDetails">
          <Form.Label>Contact Number</Form.Label>
          <Form.Control type="text" name = "contactNumber" onChange = {this.handlerChange} placeholder="Enter Contact Number" />
          
        </Form.Group>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control type="email" name = "email" onChange = {this.handlerChange} placeholder="Enter email" />
          <Form.Text className="text-muted">
            We'll never share your email with anyone else.
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formAddress">
          <Form.Label>Address</Form.Label>
          <Form.Control type="address" name = "address" onChange = {this.handlerChange} placeholder="Enter address" />
          
        </Form.Group>
        <Form.Group controlId="formSpeciality">
          <Form.Label>Speciality</Form.Label>
          <Form.Control type="text" name = "speciality" onChange = {this.handlerChange} placeholder="Enter speciality" />
         
        </Form.Group>
        <Form.Group controlId="formHospital">
          <Form.Label>Current Working Hospital</Form.Label>
          <Form.Control type="text" name = "currWorkingHospital" onChange = {this.handlerChange} placeholder="Enter Current working Hospital" />
          
        </Form.Group>
        <Button variant="primary" type="submit" onClick = {this.handlerSubmit}>
          Submit
        </Button>
      </Form>
      </div>
      )
}
}
export default doctorRegistration;







  