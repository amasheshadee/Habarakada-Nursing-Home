import React,{Component}from 'react';
import {Link} from 'react-router-dom';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
export default class ViewDoctors extends React.Component{


constructor(props){

super(props);
this.state ={

    error:null,
    isLoaded:false,
    items:[]

};

}


componentDidMount(){
    fetch("http://localhost:3000/doctorfetching")
    .then(res=>res.json())

    .then(
        (result) => {

            this.setState({

                    isLoaded:true,
                    items:result.data

            });
            console.log(result.data);
        },
        (error) =>{

            this.setState({
                isLoaded:true,
                items:[],
                error : error
            });
        }
    )
}

exportPDF = () =>{

    console.log("Entered to the export function");
    const unit = "pt";
    const size ="A4";
    const orientation = "landscape";
    const marginLeft =40;
    const doc = new jsPDF(orientation,unit,size);
    
    const title = "doctor details";
    const headers = [["Doctor Name","Contact Number","Email","Address","Speciality","Current Working Hospital"]]
    
    const appo = this.state.items.map(
    appo =>[
    
        appo.Name,
        appo.contact_number,
        appo.email,
        appo.address,
        appo.speciality,
        appo.Current_working_hospital
    
    ]
    
    );
    
    let contents = {
    
        startY:50,
        head:headers,
        body:appo
    };
    
    doc.setFontSize(20);
    doc.text(title,marginLeft,40);
    require('jspdf-autotable');
    doc.autoTable(contents);
    doc.save("DoctorDetails.pdf")
    }
    
    

render(){


    const{error,isLoaded,items}=this.state;
    if(error){
    return <div> {error.message}</div>
    }else if(!isLoaded){
        return <div> Loading.....</div>
    }
    else{
        return(
            <ul>

            <div className = "App">
                <div className = "my1">
                    <h2><b/><b/>Doctor Details</h2><br/><br/>
                    <h4><b/> Doctor information<b/></h4><br/><br/>
                    <table className = "table table-striped">
                        <thead>
                            <tr>
                                <th scope = "col"> Name</th>
                                <th scope = "col"> contact_number</th>
                                <th scope = "col"> email</th>
                                <th scope = "col"> address</th>
                                <th scope = "col"> speciality</th>
                                <th scope = "col"> Current_working_hospital</th>
                            </tr>
                        </thead>
                        {items.map(item => (
                            <tbody>
                                 <tr>
                                     <th scope ="row">{item.Name}</th>
                                     <td>{item.contact_number}</td>
                                     <td>{item.email}</td>
                                     <td>{item.address}</td>
                                     <td>{item.speciality}</td>
                                     <td>{item.Current_working_hospital}</td>

                                     <td><Link to={`/updateDoctorDetails/${item.doctor_id}`}><input type="submit" value = "UPDATE" id ="doctor"/></Link></td>
                                    </tr>

                            </tbody>

                         ) )}
                         </table>
                         <button onClick = {this.exportPDF}> Generate PO Report </button>
                    </div>
                </div>
                </ul>
        )
    }
}

}
