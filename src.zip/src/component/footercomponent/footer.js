import React from 'react';


function Footer() {
    return (
      <div className="App">
        <div class="touch-line">
		<div class="container">
			<div class="row">
				
			</div>
		</div>
	</div>
	
    <footer class="footer">
        <div class="container">
            <p class="copyright text-center">All Rights Reserved. &copy; 2020HNH || Designed & Developed By : ITPG8.1|SLIIT				
            </p>
        </div>
    </footer>
    </div>
  
  
        
      
    );
  }
  
  export default Footer;

  