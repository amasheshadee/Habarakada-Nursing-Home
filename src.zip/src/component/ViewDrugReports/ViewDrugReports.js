import React,{Component}from 'react';
import {Link} from 'react-router-dom';
export default class ViewDrugReports extends React.Component{


constructor(props){

super(props);
this.state ={

    error:null,
    isLoaded:false,
    items:[]

};

}


componentDidMount(){
    
    fetch("http://localhost:3000/drugreportfetching")
    .then(res=>res.json())

    .then(
        (result) => {

            this.setState({

                    isLoaded:true,
                    items:result.data

            });
            console.log(result.data);
        },
        (error) =>{

            this.setState({
                isLoaded:true,
                items:[],
                error : error
            });
        }
    )
}

render(){


    const{error,isLoaded,items}=this.state;
    if(error){
    return <div> {error.message}</div>
    }else if(!isLoaded){
        return <div> Loading.....</div>
    }
    else{
        return(
            <ul>

            <div className = "App">
                <div className = "my1">
                    <h2><b/><b/>Drug Details</h2><br/><br/>
                    <h4><b/> Drug information<b/></h4><br/><br/>
                    <table className = "table table-striped">
                        <thead>
                            <tr>
                                <th scope = "col"> drug_name</th>
                                <th scope = "col"> drug_quantity</th>
                                <th scope = "col"> expiredate</th>
                                <th scope = "col"> date_of_issue</th>
                            </tr>
                        </thead>
                        {items.map(item => (
                            <tbody>
                                 <tr>
                                     <th scope ="row">{item.drug_name}</th>
                                     <td>{item.drug_quantity}</td>
                                     <td>{item.expiredate}</td>
                                     <td>{item.date_of_issue}</td>

                                    
                                    </tr>

                            </tbody>

                         ) )}
                         </table>
                    </div>
                </div>
                </ul>
        )
    }
}

}
